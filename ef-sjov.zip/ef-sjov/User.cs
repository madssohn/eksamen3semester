﻿using System;
using System.Collections.Generic;
using ef_sjov.Model;
using ef_sjov;

namespace ef_sjov
{
    public class User
    {
        public User(string name)
        {
            this.Name = name;
        }
        public long UserId { get; set; }
        public string? Name { get; set; }
    }
}

