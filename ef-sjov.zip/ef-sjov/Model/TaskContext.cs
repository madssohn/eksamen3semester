﻿using System;
using System.Collections.Generic;
using ef_sjov.Model;
using Microsoft.EntityFrameworkCore;

namespace ef_sjov.Model
{
     //Den første som virker, dog ikke med user. (TaskContext1)
    public class TaskContext : DbContext
    {
        public DbSet<TodoTask> Tasks { get; set; }
        public string DbPath { get; }

        public TaskContext()
        {
            DbPath = "bin/TodoTask.db";
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlite($"Data Source={DbPath}");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TodoTask>().ToTable("Tasks");
        }
    }



}





