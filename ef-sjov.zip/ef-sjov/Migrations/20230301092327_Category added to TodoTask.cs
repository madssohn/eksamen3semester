﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ef_sjov.Migrations
{
    /// <inheritdoc />
    public partial class CategoryaddedtoTodoTask : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
