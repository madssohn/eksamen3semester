﻿using ef_sjov;
using ef_sjov.Model;

using (var db = new TaskContext())
{
    Console.WriteLine($"Database path: {db.DbPath}."); //Tjekker vores forbindelse til "bin"
    
    // Create
    Console.WriteLine("Indsæt et nyt task");
    var newUser = new User("Leo");
    db.Add(new TodoTask("En bil som skal bygges", false,"Projekt",newUser));
    db.SaveChanges();
    
    // Read
    Console.WriteLine("Find det sidste task");
    var lastTask = db.Tasks
        .OrderBy(b => b.TodoTaskId)
        .Last();
    Console.WriteLine($"Text: {lastTask.Text}");
    
    // Update
    Console.WriteLine("Opdater det første task");
    var firstTask = db.Tasks.First();
    firstTask.Text = "En opgave der er blevet opdateret";
    db.SaveChanges();

    /*
    // Delete
    Console.WriteLine("Slet det sidste task");
    db.Remove(lastTask);
    db.SaveChanges();
    */

    // Update og delete v2
    /*
    var testTask = lastTask;
    testTask.Text = "Endnu bedre opgave";
    db.SaveChanges();

    Console.WriteLine($"Text: {lastTask.Text}");

    var testTask2 = db.Tasks.First();
    db.Tasks.Remove(testTask2);
    db.SaveChanges();
    */
}
